let tokenBlacklist = [];

module.exports = tokenBlacklist;